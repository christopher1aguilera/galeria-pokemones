const { default: Axios } = require("axios")

const getPokes = () =>{
    return Axios.get('https://pokeapi.co/api/v2/pokemon?limit=50')
         .then(response => response.data.results)
}

const getPokes2 = () =>{
    // return Axios.get('https://pokeapi.co/api/v2/pokemon?limit=80')
    return Axios.get('https://pokeapi.co/api/v2/pokemon?limit=50&offset=50')
         .then(response => response.data.results)
}

const getPokes3 = () =>{
    // return Axios.get('https://pokeapi.co/api/v2/pokemon?limit=80')
    return Axios.get('https://pokeapi.co/api/v2/pokemon?limit=50&offset=100')
         .then(response => response.data.results)
}


const getPoke = (pokeNumber) =>{
   return Axios.get(`https://pokeapi.co/api/v2/pokemon/${pokeNumber}`)
         .then(response => response.data)
}
const http = require('http')
const fs = require('fs')
http
.createServer((req, res) => {
let pokePromises = [];
let arrayProperties = new Array()
if (req.url == '/galeria') {
getPokes().then(pokesInfo =>{
    pokesInfo.forEach(pokeApi=>{
        pokePromises.push(getPoke(pokeApi.name))
    })
    getPokes2().then(pokesInfo =>{
        pokesInfo.forEach(pokeApi=>{
            pokePromises.push(getPoke(pokeApi.name))
        })
        getPokes3().then(pokesInfo =>{
            pokesInfo.forEach(pokeApi=>{
                pokePromises.push(getPoke(pokeApi.name))
            })
        Promise.all(pokePromises).then(data =>{
            data.forEach((p) => {
                let imagen = `${p.sprites.front_default}`
                let pokemon = `${p.name}`
                console.log(pokemon)
                console.log(imagen)
                let info = {nombre: pokemon, img: imagen}
                arrayProperties.push(info);
            })
            var myString = JSON.stringify(arrayProperties);
            res.writeHead(200, { 'Content-Type': 'application/json' })
            res.end(myString)
            })
        })
    })
        })
    }
            else if (req.url == '/pokemones') {
                res.writeHead(200, { 'Content-Type': 'text/html' })
            fs.readFile('index.html', 'utf-8',(err,file)=>{
                if(err) throw err;
                res.write(file)
                res.end()
            })
        }
})
.listen(3000, () => console.log('Servidor encendido'))









// const axios = require('axios')
// const http = require('http')
// const fs = require('fs')

// const server = http.createServer((req,res) =>{
//   const url = req.url
//   switch(url){
//     case('/'):
//     case('/pokemones'):
//       res.writeHead(200,{'Content-Type': 'text/html'})
//       fs.readFile('index.html', 'utf-8', (err, file)=>{
//         if(err) throw err
//         res.write(file)
//         res.end()
//       })
//     break
//     case('/galeria'):
//       res.writeHead(200,{'Content-Type': 'application/json'})
//       getPokemons().then((pokemons) => {
//           const pokeInfo = pokemons.map(pokemon => getPokemon(pokemon.name))
//           Promise.all(pokeInfo).then(results =>{
//             const pokemonesFiltrados = results.map(poke => ({nombre: poke.name, img: poke.sprites.front_default }))
//             res.write(JSON.stringify(pokemonesFiltrados))
//             res.end()
//           })
//         })
//     break
//     default:
//       res.writeHead(404, {'Content-Type': 'text/html'})
//       fs.readFile('404.html','utf-8',(err, file)=>{
//         if(err) throw err
//         res.write(file)
//         res.end()
//       })
//     break
//   }
// })

// server.listen(3000, () => console.log('Servidor habilitado en puerto 3000'))

// async function getPokemons(){
//   const { data } = await axios.get('https://pokeapi.co/api/v2/pokemon?limit=150')
//   return data.results
// }

// async function getPokemon(name){
//   const { data } = await axios.get(`https://pokeapi.co/api/v2/pokemon/${name}`)
//   return data
// }